+++
author = "Hugo Authors"
title = "富文本内容测试"
date = "2019-03-10"
description = "A brief description of Hugo Shortcodes"
tags = [
    "shortcodes",
    "privacy",
]
+++

Hugo 雨果附带几个[内置的短码](https://gohugo.io/content-management/shortcodes/ use-hugos-built-in-shortcodes)内容丰富,以及[隐私配置](https://gohugo.io/about/hugo-and-gdpr/)和一组简单的短码,使静态和no-JS版本的各种社会媒体嵌入。
<!--more-->
---

## YouTube Privacy Enhanced Shortcode

{{< youtube ZJthWmvUzzc >}}

<br>

---

## Twitter Simple Shortcode

{{< twitter_simple 1085870671291310081 >}}

<br>

---

## Vimeo Simple Shortcode

{{< vimeo_simple 48912912 >}}

